/*
 * kplib.h  Used by kptop to create a UI for the kernel profiler.
 *
 * Derived from GPLed sources for "kernprof", maintained at oss.sgi.com.
 */

#ifndef _KPLIB_H

#define _KPLIB_H 1

#include "gmon_out.h"

typedef struct {
	address_t addr;
	u_int count;
	char name[248];
} prof_t;

/*
 * Type for CPU bitmaps in the kernel.  Presently the same as kaddress_t.
 * Will need to be changed once we start supporting really large CPU counts.
 */

typedef kaddress_t cpu_map_t;

int kp_init(char *mapfile, void (*errfunc)(int), char *progname);
void kp_exit(void);
void kp_stop(void);
void kp_reset(void);
void kp_set_sleep(u_int sleep);
int kp_set_event(u_int event);
int kp_set_pid(u_long pid);
int kp_set_mode(u_int mode);
int kp_set_domain(u_int domain);
int kp_set_freq(u_int freq);
void kp_set_cpu_map(cpu_map_t cpu_map);
void kp_get_cpu_map(cpu_map_t *cpu_map);
void kp_start(void);
prof_t **kp_get_prof(prof_t **table, int *entries, int *ticks);
void kp_write_file(char *filename);

#endif
