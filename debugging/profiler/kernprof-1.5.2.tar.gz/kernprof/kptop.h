/*
 * kptop.h  UI for the kernel profiler, showing top kernel functions
 *
 * Derived from GPLed sources for "top" found in Red Hat's procps-2.0.7.
 */

/*
 * top.h header file 1996/05/18, 
 *
 * function prototypes, global data definitions and string constants.
 */

#include "kplib.h"

prof_t** getproftable(prof_t** table, int *table_len);
void parse_options(char *Options);
void get_options(void);
void error_end(int rno);
void end(int signo);
void stop(int signo);
void window_size(int signo);
int make_header(void);
int getnum(void);
char *getstr(void);
int getsig(void);
float getfloat(void);
void show_fields(void);
void change_order(void);
void change_fields(void);
void show_info(prof_t *task);
void show_funcs(void);
float get_elapsed_time(void);
void do_key(char c);


/* configurable field display support */

int pflags[30];
int sflags[10];
int Numfields;


	/* Name of the config file (in $HOME)  */
#ifndef RCFILE
#define RCFILE		".kptoprc"
#endif

#ifndef SYS_TOPRC
#define SYS_TOPRC	"/etc/kptoprc"
#endif

#define MAXLINES 2048
#define MAXNAMELEN 1024

/* this is what procps top does by default, so let's do this, if nothing is
 * specified
 */
#ifndef DEFAULT_SHOW
/*                       0         1         2         3 */
/*                       0123456789012345678901234567890 */
#define DEFAULT_SHOW    "ABC"
#endif
char Fields[256] = "";


/* This structure stores some critical information from one frame to
   the next. mostly used for sorting. Added resident fields. */
struct save_hist {
    int ticks;
    int pid;
    int pcpu;
    int utime;
    int stime;
};

	/* The original terminal attributes. */
struct termios Savetty;
	/* The new terminal attributes. */
struct termios Rawtty;
	/* Cached termcap entries. */
char *cm, *cl, *top_clrtobot, *top_clrtoeol, *ho, *md, *me, *mr;
	/* Current window size.  Note that it is legal to set Display_funcs
	   larger than can fit; if the window is later resized, all will be ok.
	   In other words: Display_funcs is the specified max number of
	   functions to display (zero for infinite), and Maxlines is the actual
	   number. */
int Lines, Cols, Maxlines, Display_funcs;
	/* Maximum length to display of the command line of a process. */
unsigned Maxcmd;

	/* The top of the main loop. */
jmp_buf redraw_jmp;

	/* Controls how long we sleep between screen updates.  Accurate to
	   microseconds. */
float Sleeptime = 5;
	/* Mode flags. */
int CPU_states = 0;
int show_loadav = 1;   /* show load average and uptime */
int Loops = -1;	       /* number of iterations. -1 loops forever */
int Batch = 0;         /* batch mode. Collect no input, dumb output */
int Accumulate = 0;    /* accumulate samples across displays (default is no) */
int Idle = 1;	       /* show idle (default is to show idle) */

/* sorting order: cpu%, mem, time */
enum {
	S_COUNT, S_NAME, S_NONE
};
/* default sorting by CPU% */ 
int sort_type = S_NONE;

/* flags for each possible field. At the moment up to 30 are supported */
enum {
	KP_COUNT, KP_ADDR, KP_NAME, KP_END
};
/* corresponding headers */
char *headers[] =
{
	"     COUNT (  % ) ", "    ADDR ", "NAME"
};
/* corresponding field desciptions */
char *headers2[] =
{
	"Number of Samples", "Function Address", "Function Name"
};

	/* The header printed at the top of the process list.*/
char Header[MAXLINES];

	/* The response to the interactive 'h' command. */
#define HELP_SCREEN "\
Interactive commands are:\n\
\n\
space\tUpdate display\n\
^L\tRedraw the screen\n\
a\tDo not accumulate profiling samples\n\
b\tBegin profiling\n\
e\tEnd profiling\n\
fF\tadd and remove fields\n\
g\tGenerate gmon.out file\n\
h or ?\tPrint this list\n\
k\tKill a task (with any signal)\n\
l\tToggle display of load average\n\
n or #\tSet the number of functions to show\n\
p\tSet a pid to be profiled (0 for no pid)\n\
r\tReset profiling data\n\
s\tSet the delay in seconds between updates\n\
oO\tChange order of displayed fields\n\
A\tSort by address\n\
C\tSort by count\n\
N\tSort by name\n\
W\tWrite configuration file ~/.kptoprc\n\
q\tQuit"

	/* Number of lines needed to display the header information. */
int header_lines;

/* ############## Some Macro definitions for screen handling ######### */
	/* String to use in error messages. */
#define PROGNAME "kptop"
	/* Clear the screen. */
#define clear_screen() \
	    printf("%s", cl)
	/* Show an error in the context of the spiffy full-screen display. */
#define SHOWMESSAGE(x) do { 			\
	    printf("%s%s%s%s", tgoto(cm, 0, header_lines-2), top_clrtoeol,md,mr);	\
	    printf x;					\
	    printf ("%s",me);                           \
	    fflush(stdout);				\
	    sleep(2);					\
	} while (0)
