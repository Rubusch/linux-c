/*
 * proc.c  Used by kptop to create a UI for the kernel profiler.
 *
 * Derived from GPLed sources for "libproc" found in Red Hat's procps-2.0.7.
 */

#include <stdlib.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/utsname.h>

#include "proc.h"

/* proc/compare.c: */

/*
 *
 * Copyright 1994 Charles Blake and Michael K. Johnson
 * This file is a part of procps, which is distributable
 * under the conditions of the GNU Library General Public License.
 * See the file COPYING for details.
 *
 */


/*
  This module was written by Charles Blake for procps.
*/

/* the only reason these are global is because qsort(3) likes it that way.
   It's also a little more efficient if mult_lvl_cmp() is called many times.
*/

typedef int (*cmp_t)(void*,void*);	/* for function pointer casts */

int sort_depth = 0;
int sort_direction[10];     /* storage for 10 levels, but 4 would be plenty!*/
int (*sort_function[10])(void* a, void* b);

int mult_lvl_cmp(void* a, void* b) {
    int i, cmp_val;
    for(i = 0; i < sort_depth; i++) {
        cmp_val = sort_direction[i] * (*sort_function[i])(a,b);
        if (cmp_val != 0)
            return cmp_val;
    }
    return 0;
}

void reset_sort_options (void)
{
  int i;

  sort_depth=0;
  for (i=0;i<10;i++){
    sort_direction[i]=0;
    sort_function[i]=(cmp_t)NULL;
  }
}

void register_sort_function (int dir, cmp_t func)
{
    sort_function[sort_depth] = func;
    sort_direction[sort_depth++] = dir;
}


/* proc/version.c: */

/* Suite version information for procps utilities
 * Copyright (c) 1995 Martin Schulze <joey@infodrom.north.de>
 * Ammended by cblake to only export the function symbol.
 * Redistributable under the terms of the
 * GNU Library General Public License; see COPYING
 */

/* Linux kernel version information for procps utilities
 * Copyright (c) 1996 Charles Blake <cblake@bbn.com>
 */

#define LINUX_VERSION(x,y,z)   (0x10000*(x) + 0x100*(y) + z)

int linux_version_code = 0;

static void init_Linux_version(void) {
    static struct utsname uts;
    int x = 0, y = 0, z = 0;	/* cleared in case sscanf() < 3 */
    
    if (linux_version_code) return;
    if (uname(&uts) == -1)	/* failure implies impending death */
	exit(1);
    if (sscanf(uts.release, "%d.%d.%d", &x, &y, &z) < 3)
	fprintf(stderr,		/* *very* unlikely to happen by accident */
		"Non-standard uts for running kernel:\n"
		"release %s=%d.%d.%d gives version code %d\n",
		uts.release, x, y, z, LINUX_VERSION(x,y,z));
    linux_version_code = LINUX_VERSION(x, y, z);
}


/* proc/signals.c: */

typedef struct {
    int number;
    char *name;
} SIGNAME;


static SIGNAME signals[] = {
{ 1,"HUP" },
{ 2,"INT" },
{ 3,"QUIT" },
{ 4,"ILL" },
{ 5,"TRAP" },
{ 6,"ABRT" },
{ 6,"IOT" },
{ 7,"EMT" },
{ 8,"FPE" },
{ 9,"KILL" },
{ 10,"BUS" },
{ 11,"SEGV" },
{ 12,"SYS" },
{ 13,"PIPE" },
{ 14,"ALRM" },
{ 15,"TERM" },
{ 16,"URG" },
{ 17,"STOP" },
{ 18,"TSTP" },
{ 19,"CONT" },
{ 20,"CHLD" },
{ 21,"TTIN" },
{ 22,"TTOU" },
{ 23,"IO" },
{ 24,"XCPU" },
{ 25,"XFSZ" },
{ 26,"VTALRM" },
{ 27,"PROF" },
{ 28,"WINCH" },
{ 29,"LOST" },
{ 30,"USR1" },
{ 31,"USR2" },
  { 0,NULL }};


/* get_signal2 is by Michael Shields. 1994/04/25. */
int get_signal2(char *name)
{
    SIGNAME *walk;

    if (!name)
        return(-1);
    if (isdigit(*name))
	return atoi(name);
    for (walk = signals; walk->name; walk++)
        if (!strcmp(walk->name,name))
            return(walk->number);
    return(-1);
}


/* proc/sysinfo.c: */

/***********************************************************************\
*   Copyright (C) 1992-1998 by Michael K. Johnson, johnsonm@redhat.com *
*                                                                      *
*      This file is placed under the conditions of the GNU Library     *
*      General Public License, version 2, or any later version.        *
*      See file COPYING for information on distribution conditions.    *
\***********************************************************************/

/* File for parsing top-level /proc entities. */

#define BAD_OPEN_MESSAGE					\
"Error: /proc must be mounted\n"				\
"  To mount /proc at boot you need an /etc/fstab line like:\n"	\
"      /proc   /proc   proc    defaults\n"			\
"  In the meantime, mount /proc /proc -t proc\n"

#define LOADAVG_FILE "/proc/loadavg"
static int loadavg_fd = -1;

static char sibuf[1024];

/* This macro opens filename only if necessary and seeks to 0 so
 * that successive calls to the functions are more efficient.
 * It also reads the current contents of the file into the global buf.
 */
#define FILE_TO_BUF(filename, fd) do{				\
    static int n;						\
    if (fd == -1 && (fd = open(filename, O_RDONLY)) == -1) {	\
	fprintf(stderr, BAD_OPEN_MESSAGE);			\
	close(fd);						\
	_exit(1);						\
    }								\
    lseek(fd, 0L, SEEK_SET);					\
    if ((n = read(fd, sibuf, sizeof sibuf - 1)) < 0) {		\
	perror(filename);					\
	close(fd);						\
	fd = -1;						\
	return 0;						\
    }								\
    sibuf[n] = '\0';						\
}while(0)

#define SET_IF_DESIRED(x,y)  if(x) *(x) = (y)	/* evals 'x' twice */

/* /proc files are output in C locale, while we might be using
 * some other locale.  Make sure we parse double values with
 * a "C" locale dot.
 */
#define ONE_DOUBLE(val, buf, failed) ({				\
    double _d;							\
    char *_p, *_q;						\
    val = strtoul(buf, &_p, 10);				\
    if (_p == buf && *_p != '.')				\
	failed = 1;						\
    if (*_p == '.') {						\
	_p++;							\
	if (*_p >= '0' && *_p <= '9') {				\
	    _d = strtoul(_p, &_q, 10);				\
	    while (_p != _q) _d /= 10, _p++;			\
	    if (val < 0)					\
		val -= _d;					\
	    else						\
		val += _d;					\
	}							\
    }								\
    _p; })


/***********************************************************************/
int loadavg(double *av1, double *av5, double *av15) {
    double avg_1=0, avg_5=0, avg_15=0;
    char *p;
    int failed = 0;
    
    FILE_TO_BUF(LOADAVG_FILE,loadavg_fd);
    p = ONE_DOUBLE(avg_1, sibuf, failed);
    if (*p != ' ' && *p != '\t') failed = 1;
    p = ONE_DOUBLE(avg_5, p, failed);
    if (*p != ' ' && *p != '\t') failed = 1;
    ONE_DOUBLE(avg_15, p, failed);
    if (failed) {
	fprintf(stderr, "bad data in " LOADAVG_FILE "\n");
	exit(1);
    }
    SET_IF_DESIRED(av1,  avg_1);
    SET_IF_DESIRED(av5,  avg_5);
    SET_IF_DESIRED(av15, avg_15);
    return 1;
}
