/*
 * proc.h  Used by kptop to create a UI for the kernel profiler.
 *
 * Derived from GPLed sources for "libproc" found in Red Hat's procps-2.0.7.
 */

/* The shadow of the original with only common prototypes now. */
#include <stdio.h>
#include <sys/types.h>
#include <string.h>		/* for strcmp */

char *find_func(unsigned long address);
int   mult_lvl_cmp(void* a, void* b);

int   open_psdb(const char *override);
int   open_psdb_message(const char *override, void (*message)(const char *, ...));
void  close_psdb(void);

int loadavg(double *av1, double *av5, double *av15);
