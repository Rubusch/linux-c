/*
 * kptop.c  UI for the kernel profiler, showing top kernel functions
 *
 * Derived from GPLed sources for "top" found in Red Hat's procps-2.0.7.
 */

/*
 * top.c              - show top CPU processes
 *
 * Copyright (c) 1992 Branko Lankester
 * Copyright (c) 1992 Roger Binns
 * Copyright (c) 1997 Michael K. Johnson
 *
 * Snarfed and HEAVILY modified in december 1992 for procps
 * by Michael K. Johnson, johnsonm@sunsite.unc.edu.
 *
 * Modified Michael K. Johnson's ps to make it a top program.
 * Also borrowed elements of Roger Binns kmem based top program.
 * Changes made by Robert J. Nation (nation@rocket.sanders.lockheed.com)
 * 1/93
 *
 * Modified by Michael K. Johnson to be more efficient in cpu use
 * 2/21/93
 *
 * Changed top line to use uptime for the load average.  Also
 * added SIGTSTP handling.  J. Cowley, 19 Mar 1993.
 *
 * Modified quite a bit by Michael Shields (mjshield@nyx.cs.du.edu)
 * 1994/04/02.  Secure mode added.  "d" option added.  Argument parsing
 * improved.  Switched order of tick display to user, system, nice, idle,
 * because it makes more sense that way.  Style regularized (to K&R,
 * more or less).  Cleaned up much throughout.  Added cumulative mode.
 * Help screen improved.
 *
 * Fixed kill buglet brought to my attention by Rob Hooft.
 * Problem was mixing of stdio and read()/write().  Added
 * getnum() to solve problem.
 * 12/30/93 Michael K. Johnson
 *
 * Added toggling output of idle processes via 'i' key.
 * 3/29/94 Gregory K. Nickonov
 *
 * Fixed buglet where rawmode wasn't getting restored.
 * Added defaults for signal to send and nice value to use.
 * 5/4/94 Jon Tombs.
 *
 * Modified 1994/04/25 Michael Shields <mjshield@nyx.cs.du.edu>
 * Merged previous changes to 0.8 into 0.95.
 * Allowed the use of symbolic names (e.g., "HUP") for signal input.
 * Rewrote getnum() into getstr(), getint(), getsig(), etc.
 * 
 * Modified 1995  Helmut Geyer <Helmut.Geyer@iwr.uni-heidelberg.de> 
 * added kmem top functionality (configurable fields)
 * configurable order of process display
 * Added options for dis/enabling uptime, statistics, and memory info.
 * fixed minor bugs for ELF systems (e.g. SIZE, RSS fields)
 *
 * Modified 1996/05/18 Helmut Geyer <Helmut.Geyer@iwr.uni-heidelberg.de>
 * Use of new interface and general cleanup. The code should be far more
 * readable than before.
 *
 * Modified 1996/06/25 Zygo Blaxell <zblaxell@ultratech.net>
 * Added field scaling code for programs that run more than two hours or
 * take up more than 100 megs.  We have lots of both on our production line.
 *
 * Modified 1998/02/21 Kirk Bauer <kirk@kaybee.org>
 * Added the 'u' option to display only a selected user... plus it will
 * take into account that not all 20 top processes are actually shown,
 * so it can fit more onto the screen.  I think this may help the
 * 'don't show idle' mode, but I'm not sure.
 *
 * Modified 1997/07/27 & 1999/01/27 Tim Janik <timj@gtk.org>
 * added `-p' option to display specific process ids.
 * process sorting is by default disabled in this case.
 * added `N' and `A' keys to sort the tasks Numerically by pid or
 * sort them by Age (newest first).
 *
 * Modified 1999/10/22 Tim Janik <timj@gtk.org>
 * miscellaneous minor fixes, including "usage: ..." output for
 * unrecognized options.
 *
 * Modified 2000/02/07 Jakub Jelinek <jakub@redhat.com>
 * Only load System.map when we are going to display WCHAN.
 * Show possible error messages from that load using SHOWMESSAGE.
 *
 * Modified 2000/07/10 Michael K. Johnson <johnsonm@redhat.com>
 * Integrated a patch to display SMP information.
 */

#include <errno.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <libintl.h>
#include <time.h>
#include <sys/ioctl.h>
#include <pwd.h>
#include <termcap.h>
#include <termios.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <ctype.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/param.h>
#include <locale.h>
#include <langinfo.h>
#include <linux/kernprof.h>

#include "gmon_out.h"
#include "proc.h"
/* these should be in the readproc.h header or in the procps.h header */
typedef int (*cmp_t)(void*,void*);
extern void reset_sort_options (void);
extern void register_sort_function (int dir, cmp_t func);

char *sprint_loadavg(void);

#define PUTP(x) (tputs(x,1,putchar))
#define BAD_INPUT -30

#include "kptop.h"  /* new header for top specific things */

static void top_message(const char *format, ...);
static int nr_cpu;
static char *decimal_point;
static char System_map[256];
static int tot_ticks;
static int pid = 0;
static int mode;		/* 0 == acg, 1 == bt */
static int kernprof_mode = PROF_MODE_PC_SAMPLING | PROF_MODE_CALL_GRAPH;
static int running;
static int got_mcount;
static int num_cpus;

#define KPTOP_VERS "v0.1.2"


int count_sort(prof_t **P, prof_t **Q)
{
	if( (*P)->count < (*Q)->count )      return -1;
	if( (*P)->count > (*Q)->count )      return 1;
	return 0;
}

int name_sort(prof_t **P, prof_t **Q)
{
	return strcmp((*P)->name, (*Q)->name) * -1;
}




/*#######################################################################
 *####  Startup routines: parse_options, get_options,      ##############
 *####                    setup_terminal and main          ##############
 *#######################################################################
 */

      /*
       * parse the options string as read from the config file(s).
       */
void parse_options(char *Options)
{
	int i;
	for (i = 0; i < strlen(Options); i++) {
		switch (Options[i]) {
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			Sleeptime = (float) Options[i] - '0';
			break;
		case 'l':
			show_loadav = 0;
			header_lines -= 1;
			break;
		case 'N':
			sort_type = S_NAME;
			reset_sort_options();
			register_sort_function( -1, (cmp_t)name_sort);
			break;
		case 'C':
			sort_type = S_COUNT;
			reset_sort_options();
			register_sort_function( -1, (cmp_t)count_sort);
			break;
		case 'a':
			Accumulate = 1;
			break;
		case 'i':
			Idle = 1;
			break;
		case '\n':
			break;
		default:
			fprintf(stderr, "Wrong configuration option %c\n", i);
			exit(1);
			break;
		}
	}
}

/* 
 * Read the configuration file(s).
 * 
 * The other file is $HOME/RCFILE. 
 * The configuration file should contain two lines (any of which may be
 *  empty). The first line specifies the fields that are to be displayed
 * in the order you want them to. Uppercase letters specify fields 
 * displayed by default, lowercase letters specify fields not shown by
 * default. The order of the letters in this line corresponds to the 
 * order of the displayed fileds.
 *
 * all Options but 'q' can be read from this config file
 * The delay time option syntax differs from the commandline syntax:
 *   only integer values between 2 and 9 seconds are recognized
 *   (this is for standard configuration, so I think this should do).
 *
 * usually this file is not edited by hand, but written from top using
 * the 'W' command. 
 */

void get_options(void)
{
	FILE *fp;
	char *pt;
	char rcfile[MAXNAMELEN];
	char Options[256] = "";
	int i;

#ifdef XXX
	nr_cpu = sysconf (_SC_NPROCESSORS_ONLN);
	header_lines = 2 + nr_cpu;
#else
	header_lines = 3;
#endif
	strcpy(rcfile, SYS_TOPRC);
	fp = fopen(rcfile, "r");
	if (fp != NULL) {
		fgets(Options, 254, fp);
		fclose(fp);
	}
	parse_options(Options);
	strcpy(Options, "");
	if (getenv("HOME")) {
		strcpy(rcfile, getenv("HOME"));
		strcat(rcfile, "/");
	}
	strcat(rcfile, RCFILE);
	fp = fopen(rcfile, "r");
	if (fp == NULL) {
		strcpy(Fields, DEFAULT_SHOW);
	} else {
		if (fgets(Fields, 254, fp) != NULL) {
			pt = strchr(Fields, '\n');
			if (pt) *pt = 0;
		}
		fgets(Options, 254, fp);
		fclose(fp);
	}
	parse_options(Options);
}

/*
     * Set up the terminal attributes.
     */
void setup_terminal(void)
{
	char *termtype;
	struct termios newtty;
	if (!Batch)
		termtype = getenv("TERM");
	else 
		termtype = "dumb";
	if (!termtype) {
		/* In theory, $TERM should never not be set, but in practice,
		   some gettys don't.  Fortunately, vt100 is nearly always
		   correct (or pretty close). */
		termtype = "VT100";
		/* fprintf(stderr, PROGNAME ": $TERM not set\n"); */
		/* exit(1); */
	}

	/*
	 * Get termcap entries and window size.
	 */
	if(tgetent(NULL, termtype) != 1) {
		fprintf(stderr, PROGNAME ": Unknown terminal \"%s\" in $TERM\n",
			termtype);
		exit(1);
	}

	cm = tgetstr("cm", 0);
	top_clrtobot = tgetstr("cd", 0);
	cl = tgetstr("cl", 0);
	top_clrtoeol = tgetstr("ce", 0);
	ho = tgetstr("ho", 0);
	md = tgetstr("md", 0);
	mr = tgetstr("mr", 0);
	me = tgetstr("me", 0);


	if (Batch) return; /* the rest doesn't apply to batch mode */
	if (tcgetattr(0, &Savetty) == -1) {
		perror(PROGNAME ": tcgetattr() failed");
		error_end(errno);
	}
	newtty = Savetty;
	newtty.c_lflag &= ~ICANON;
	newtty.c_lflag &= ~ECHO;
	newtty.c_cc[VMIN] = 1;
	newtty.c_cc[VTIME] = 0;
	if (tcsetattr(0, TCSAFLUSH, &newtty) == -1) {
		printf("cannot put tty into raw mode\n");
		error_end(1);
	}
	tcgetattr(0, &Rawtty);
}

int main(int argc, char **argv)
{
	/* For select(2). */
	struct timeval tv;
	fd_set in;
	/* For parsing arguments. */
	char *cp;
	/* The key read in. */
	char c;
	float time;
	cpu_map_t cpus;

	struct sigaction sact;

	if (getuid()) {
		fprintf(stderr, PROGNAME ": must run as root\n");
		exit(1);
	}

	setlocale(LC_ALL, "");
	decimal_point = nl_langinfo(DECIMAL_POINT);
	get_options();
    
	/* set to count sorting */
	register_sort_function(-1, (cmp_t)count_sort);
	sort_type = S_COUNT;

	/*
	 * Parse arguments.
	 */
	argv++;
	while (*argv) {
		cp = *argv++;
		while (*cp) {
			switch (*cp) {
			case 'd':
				if (cp[1]) {
					if (sscanf(++cp, "%f", &Sleeptime) != 1) {
						fprintf(stderr, PROGNAME ": Bad delay time `%s'\n", cp);
						exit(1);
					}
					goto breakargv;
				} else if (*argv) { /* last char in an argv, use next as arg */
					if (sscanf(cp = *argv++, "%f", &Sleeptime) != 1) {
						fprintf(stderr, PROGNAME ": Bad delay time `%s'\n", cp);
						exit(1);
					}
					goto breakargv;
				} else {
					fprintf(stderr, "-d requires an argument\n");
					exit(1);
				}
				break;
			case 'n':
				if (cp[1]) {
					if (sscanf(++cp, "%d", &Loops) != 1) {
						fprintf(stderr, PROGNAME ": Bad value `%s'\n", cp);
						exit(1);
					}
					goto breakargv;
				} else if (*argv) { /* last char in an argv, use next as arg */
					if (sscanf(cp = *argv++, "%d", &Loops) != 1) {
						fprintf(stderr, PROGNAME ": Bad value `%s'\n", cp);
						exit(1);
					}
					goto breakargv;
				}
				break;
					
			case 'a':
				Accumulate = 1;
				break;
			case 'i':
				Idle = 0;
				break;
			case 'q':
				Sleeptime = 0;
				break;
			case 'b':
				Batch = 1;
				break;
			case '-':
				break;		/* Just ignore it */
			case 'v':
			case 'V':
				fprintf(stdout, "kptop " KPTOP_VERS "\n");
				exit(0);
			case 'h':
				fprintf(stdout, "usage: " PROGNAME " -hvbqa -m System.map -d delay -n iterations\n");
				exit(0);
			case 'm':
				if (cp[1])
					strncpy(System_map, &cp[1], 255);
				else if (*argv)
					strncpy(System_map, *argv++, 255);
				else {
					fprintf(stderr, "-S requires an argument\n");
					exit(1);
				}
				System_map[255] = '\0';
				break;
			case 'p':
				kernprof_mode = PROF_MODE_PC_SAMPLING;
				break;
			default:
				fprintf(stderr, PROGNAME ": Unknown argument `%c'\n", *cp);
				fprintf(stdout, "usage: " PROGNAME " -hvbqa -m System.map -d delay -n iterations\n");
				exit(1);
			}
			cp++;
		}
	breakargv:
	}
    
	if (kp_init(System_map[0] ? System_map : NULL, error_end, PROGNAME)) {
		fprintf(stderr, PROGNAME ": Could not initialize kplib\n");
		exit(1);
	}
	if (kp_set_mode(kernprof_mode) != 0) {
		fprintf(stderr, PROGNAME ": Could not set profiling mode\n");
		exit(1);
	}
	got_mcount = (kernprof_mode & PROF_MODE_CALL_GRAPH);
	kp_get_cpu_map(&cpus);
	num_cpus = 0;
	while (cpus) {
		if (cpus & 1)
			num_cpus++;
		cpus >>= 1;
	}
	mode = 0;
	kp_reset();
	kp_start();
	running = 1;

	setup_terminal();
	window_size(0);
	/*
	 * Set up signal handlers.
     */
	sact.sa_handler = end;
	sact.sa_flags = 0;
	sigemptyset(&sact.sa_mask);
	sigaction(SIGHUP, &sact, NULL);
	sigaction(SIGINT, &sact, NULL);
	sigaction(SIGQUIT, &sact, NULL);
	sact.sa_handler = stop;
	sact.sa_flags = SA_RESTART;
	sigaction(SIGTSTP, &sact, NULL);
	sact.sa_handler = window_size;
	sigaction(SIGWINCH, &sact, NULL);
	sigaction(SIGCONT, &sact, NULL);

    /* loop, collecting process info and sleeping */
	while (1) {
		if (Loops > 0)
			Loops--;
		/* display the tasks */
		show_funcs();
		/* sleep & wait for keyboard input */
		if (Loops == 0)
			end(0);
		time = (mode ? 1 : Sleeptime);
		if (!Batch)
		{
			tv.tv_sec = time;
			tv.tv_usec = (time - (int) time) * 1000000;
			FD_ZERO(&in);
			FD_SET(0, &in);
			if (select(1, &in, 0, 0, &tv) > 0 && read(0, &c, 1) == 1)
				do_key(c);
		} else {
			sleep(time);
		}
	}
}

/*#######################################################################
 *#### Signal handled routines: error_end, end, stop, window_size     ###
 *#### Small utilities: make_header, getstr, getint, getfloat, getsig ###
 *#######################################################################
 */


	/*
	 *  end when exiting with an error.
	 */
void error_end(int rno)
{
	kp_exit();
	if (!Batch)
		tcsetattr(0, TCSAFLUSH, &Savetty);
	PUTP(tgoto(cm, 0, Lines - 1));
	fputs("\r\n", stdout);
	exit(rno);
}
/*
	 * Normal end of execution.
	 */
void end(int signo)
{
	kp_exit();
	if (!Batch)
		tcsetattr(0, TCSAFLUSH, &Savetty);
	PUTP(tgoto(cm, 0, Lines - 1));
	fputs("\r\n", stdout);
	exit(0);
}

/*
	 * SIGTSTP catcher.
	 */
void stop(int signo)
{
	/* Reset terminal. */
	if (!Batch)
		tcsetattr(0, TCSAFLUSH, &Savetty);
	PUTP(tgoto(cm, 0, Lines - 3));
	fflush(stdout);
	raise(SIGSTOP);
	/* Later... */
	if (!Batch)
		tcsetattr (0, TCSAFLUSH, &Rawtty);
}

/*
       * Reads the window size and clear the window.  This is called on setup,
       * and also catches SIGWINCHs, and adjusts Maxlines.  Basically, this is
       * the central place for window size stuff.
       */
void window_size(int signo)
{
	struct winsize ws;

	if((ioctl(1, TIOCGWINSZ, &ws) != -1) && (ws.ws_col>73) && (ws.ws_row>7)){
		Cols = ws.ws_col;
		Lines = ws.ws_row;
	}else{
		Cols = tgetnum("co");
		Lines = tgetnum("li");
	}
	if (!Batch)
		clear_screen();
	/*
	 * calculate header size, length of cmdline field ...
	 */
	Numfields = make_header();
}

/*
	* this prints a possible message from open_psdb_message
	*/
static void top_message(const char *format, ...) {
	va_list arg;
	int n;
	char buffer[512];

	va_start (arg, format);
	n = vsnprintf (buffer, 512, format, arg);
	va_end (arg);
	if (n > -1 && n < 512)
		SHOWMESSAGE(("%s", buffer));
}

/*
       * this adjusts the lines needed for the header to the current value
       */
int make_header(void)
{
	int i, j;

	j = 0;
	for (i = 0; i < strlen(Fields); i++) {
		if (Fields[i] < 'a')
			pflags[j++] = Fields[i] - 'A';
	}
	strcpy(Header, "");
	for (i = 0; i < j; i++)
		strcat(Header, headers[pflags[i]]);
	/* readjust window size ... */
	Maxcmd = Cols - strlen(Header) + 8;
	Maxlines = Display_funcs ? Display_funcs : Lines - header_lines;
	if (Maxlines > Lines - header_lines)
		Maxlines = Lines - header_lines;
	return (j);
}



/*
 * Get a string from the user; the base of getint(), et al.  This really
 * ought to handle long input lines and errors better.  NB: The pointer
 * returned is a statically allocated buffer, so don't expect it to
 * persist between calls.
 */
char *getstr(void)
{
	static char line[BUFSIZ];	/* BUFSIZ from <stdio.h>; arbitrary */
	int i = 0;

	/* Must make sure that buffered IO doesn't kill us. */
	fflush(stdout);
	fflush(stdin);		/* Not POSIX but ok */

	do {
		read(STDIN_FILENO, &line[i], 1);
	} while (line[i++] != '\n' && i < sizeof(line));
	line[--i] = 0;

	return (line);
}


/*
 * Get an integer from the user.  Display an error message and return BAD_INPUT
 * if it's invalid; else return the number.
 */
int getint(void)
{
	char *line;
	int i;
	int r;

	line = getstr();

	for (i = 0; line[i]; i++) {
		if (!isdigit(line[i]) && line[i] != '-') {
			SHOWMESSAGE(("That's not a number!"));
			return (BAD_INPUT);
		}
	}

	/* An empty line is a legal error (hah!). */
	if (!line[0])
		return (BAD_INPUT);

	sscanf(line, "%d", &r);
	return (r);
}


/*
	 * Get a float from the user.  Just like getint().
	 */
float getfloat(void)
{
	char *line;
	int i;
	float r;

	line = getstr();

	for (i = 0; line[i]; i++) {
		if (!isdigit(line[i]) && line[i] != '.' && line[i] != '-') {
			SHOWMESSAGE(("That's not a float!"));
			return (BAD_INPUT);
		}
	}

	/* An empty line is a legal error (hah!). */
	if (!line[0])
		return (BAD_INPUT);

	sscanf(line, "%f", &r);
	return (r);
}


/*
	 * Get a signal number or name from the user.  Return the number, or -1
	 * on error.
	 */
int getsig(void)
{
	char *line;

	/* This is easy. */
	line = getstr();
	return (get_signal2(line));
}

/*#######################################################################
 *####  Routines handling the field selection/ordering screens:  ########
 *####    show_fields, change_order, change_fields               ########
 *#######################################################################
 */

        /*
	 * Display the specification line of all fields. Upper case indicates
	 * a displayed field, display order is according to the order of the 
	 * letters. A short description of each field is shown as well.
	 * The description of a displayed field is marked by a leading 
	 * asterisk (*).
	 */
void show_fields(void)
{
	int i, row, col;
	char *p;

	clear_screen();
	PUTP(tgoto(cm, 3, 0));
	printf("Current Field Order: %s\n", Fields);
	for (i = 0; i < sizeof headers / sizeof headers[0]; ++i) {
		row = i % (Lines - 3) + 3;
		col = i / (Lines - 3) * 40;
		PUTP(tgoto(cm, col, row));
		for (p = headers[i]; *p == ' '; ++p);
		printf("%c %c: %-10s = %s", (strchr(Fields, i + 'A') != NULL) ? '*' : ' ', i + 'A',
		       p, headers2[i]);
	}
}

/*
	 * change order of displayed fields
	 */
void change_order(void)
{
	char c, ch, *p;
	int i;

	show_fields();
	for (;;) {
		PUTP(tgoto(cm, 0, 0));
		PUTP(top_clrtoeol);
		PUTP(tgoto(cm, 3, 0));
		PUTP(mr);
		printf("Current Field Order: %s", Fields);
		PUTP(me);
		putchar('\n');
		PUTP(tgoto(cm, 0, 1));
		printf("Upper case characters move a field to the left, lower case to the right");
		fflush(stdout);
		if (!Batch) { /* should always be true, but... */
			tcsetattr(0, TCSAFLUSH, &Rawtty);
			read(0, &c, 1);
			tcsetattr(0, TCSAFLUSH, &Savetty);
		}
		i = toupper(c) - 'A';
		if ((p = strchr(Fields, i + 'A')) != NULL) {
			if (isupper(c))
				p--;
			if ((p[1] != '\0') && (p >= Fields)) {
				ch = p[0];
				p[0] = p[1];
				p[1] = ch;
			}
		} else if ((p = strchr(Fields, i + 'a')) != NULL) {
			if (isupper(c))
				p--;
			if ((p[1] != '\0') && (p >= Fields)) {
				ch = p[0];
				p[0] = p[1];
				p[1] = ch;
			}
		} else {
			break;
		}
	}
	Numfields = make_header();
}
/*
	 * toggle displayed fields
	 */
void change_fields(void)
{
	int i, changed = 0;
	int row, col;
	char c, *p;
	char tmp[2] = " ";

	show_fields();
	for (;;) {
		PUTP(tgoto(cm, 0, 0));
		PUTP(top_clrtoeol);
		PUTP(tgoto(cm, 3, 0));
		PUTP(mr);
		printf("Current Field Order: %s", Fields);
		PUTP(me);
		putchar('\n');
		PUTP(tgoto(cm, 0, 1));
		printf("Toggle fields with a-x, any other key to return: ");
		fflush(stdout);
		if (!Batch) { /* should always be true, but... */
			tcsetattr(0, TCSAFLUSH, &Rawtty);
			read(0, &c, 1);
			tcsetattr(0, TCSAFLUSH, &Savetty);
		}
		i = toupper(c) - 'A';
		if (i >= 0 && i < sizeof headers / sizeof headers[0]) {
			row = i % (Lines - 3) + 3;
			col = i / (Lines - 3) * 40;
			PUTP(tgoto(cm, col, row));
			if ((p = strchr(Fields, i + 'A')) != NULL) {	/* deselect Field */
				*p = i + 'a';
				putchar(' ');
			} else if ((p = strchr(Fields, i + 'a')) != NULL) {		/* select previously */
				*p = i + 'A';	/* deselected field */
				putchar('*');
			} else {		/* select new field */
				tmp[0] = i + 'A';
				strcat(Fields, tmp);
				putchar('*');
			}
			changed = 1;
			fflush(stdout);
		} else
			break;
	}
	if (changed)
		Numfields = make_header();
}

/* Do the scaling stuff
   scale_time(time,width) - interprets time in seconds, formats it to fit width

   Both return pointer to static char*.
*/

char *scale_time(int time,int width) 
{
	static char buf[100];

	/* Try successively higher units until it fits */

	sprintf(buf,"%d:%02d",time/60,time%60);	/* minutes:seconds */
	if (strlen(buf)<=width) 
		return buf;

	time/=60;	/* minutes */
	sprintf(buf,"%dm",time);
	if (strlen(buf)<=width) 
		return buf;

	time/=60;	/* hours */
	sprintf(buf,"%dh",time);
	if (strlen(buf)<=width) 
		return buf;

	time/=24;	/* days */
	sprintf(buf,"%dd",time);
	if (strlen(buf)<=width) 
		return buf;
	
	time/=7;	/* weeks */
	sprintf(buf,"%dw",time);
	return buf;	/* this is our last try; 
			   if it still doesn't fit, too bad. */

	/* :-) I suppose if someone has a SMP version of Linux with a few
           thousand processors, they could accumulate 18 years of CPU time... */
           
}

/*   scale_k(k,width,unit)  - interprets k as a count, formats to fit width.
                            if unit is 0, k is a byte count; 1 is a kilobyte
			    count; 2 for megabytes; 3 for gigabytes.
*/

char *scale_k(int k,int width,int unit) 
{
	/* kilobytes, megabytes, gigabytes, too-big-for-int-bytes */
	static double scale[]={1024,1024*1024,1024*1024*1024,0};
	/* kilo, mega, giga, tera */
	static char unitletters[]={'K','M','G','T',0};
	static char buf[100];
	char *up;
	double *dp;

	/* Try successively higher units until it fits */

	sprintf(buf,"%d",k);
	if (strlen(buf)<=width) 
		return buf;

	for (up=unitletters+unit,dp=scale ; *dp ; ++dp,++up) {
		sprintf(buf,"%.1f%c",k / *dp,*up);
		if (strlen(buf)<=width) 
			return buf;
		sprintf(buf,"%d%c",(int)(k / *dp),*up);
		if (strlen(buf)<=width) 
			return buf;
	}

	/* Give up; give them what we got on our shortest attempt */
	return buf;
}

/*
 *#######################################################################
 *####  Routines handling the main top screen:                   ########
 *####    show_task_info, show_funcs, do_stats                   ########
 *#######################################################################
 */
	/*
	 * Displays infos for a single task
	 */
void show_info(prof_t *entry)
{
	int i,j;
	unsigned int t;
	char *cmdptr;
	char tmp[2048], tmp2[2048] = "", *p;
	long count;

	for (i = 0; i < Numfields; i++) {
		tmp[0] = 0;
		switch (pflags[i]) {
		case KP_COUNT:
		{
#ifdef XXX_ORIG
			count = entry->count * 100 * (pid ? 1 : num_cpus);
			count += tot_ticks / 2;
#else
			count = entry->count * 100;
#endif
			sprintf(tmp, "%10d (%4.1f) ", entry->count,
				(float)count / (float)tot_ticks);
		}
			break;
		case KP_ADDR:
			sprintf(tmp, "%8lx ", entry->addr);
			break;
		case KP_NAME:
			if (strlen(entry->name) > Maxcmd)
				entry->name[Maxcmd - 1] = 0;
			sprintf(tmp, "%s", entry->name);
			break;
		}
		strcat(tmp2, tmp);
	}
	if (strlen(tmp2) > Cols - 1)
		tmp2[Cols - 1] = 0;

	/* take care of cases like:
	   perl -e 'foo
	   bar foo bar
	   foo
	   # end of perl script'
	*/
	for (p=tmp2;*p;++p)
		if (!isgraph(*p))
			*p=' ';

	printf("\n%s", tmp2);
	PUTP(top_clrtoeol);
}

/*
 * This is the real program!  Read prof info and display it.
 */
void show_funcs(void)
{
	static prof_t **table=NULL;
	int count, table_len;
	float elapsed_time;
	unsigned int main_mem;
	static int first = 1;

	if (Batch && first) {
		fputs("\n\n",stdout);
		first = 0;
	}
	/* Display the load averages. */
	PUTP(ho);
	PUTP(md);
	table=getproftable(table, &table_len);
	if (show_loadav) {
		printf("%s", sprint_loadavg());
		PUTP(top_clrtoeol);
		putchar('\n');
	}
	elapsed_time = get_elapsed_time();
	qsort(table, table_len, sizeof(prof_t*), (void*)mult_lvl_cmp);

	PUTP(me);
	PUTP(top_clrtoeol);
	putchar('\n');
	if (strlen(Header) + 2 > Cols)
		Header[Cols - 2] = 0;
	PUTP(mr);
	fputs(Header, stdout);
	PUTP(top_clrtoeol);
	PUTP(me);

	/*
	 * Finally!  Loop through to find the top task, and display it.
	 * Lather, rinse, repeat.
	 */
	count = 0;
	while ((Batch || (count < Maxlines)) && count < table_len)
	{
		show_info(table[count]);
		count++;
	}
	PUTP(top_clrtobot);
	PUTP(tgoto(cm, 0, header_lines - 2));
	fflush(stdout);
}


/*
 * Finds the current time (in microseconds) and calculates the time
 * elapsed since the last update. This is essential for computing
 * percent CPU usage.
 */
float get_elapsed_time(void)
{
	struct timeval time;
	static struct timeval oldtime;
	struct timezone timez;
	float elapsed_time;

	gettimeofday(&time, &timez);
	elapsed_time = (time.tv_sec - oldtime.tv_sec)
		+ (float) (time.tv_usec - oldtime.tv_usec) / 1000000.0;
	oldtime.tv_sec = time.tv_sec;
	oldtime.tv_usec = time.tv_usec;
	return (elapsed_time);
}


/* Trim to zero if we get negative time ticks, which
   may happen on some kernels. (see Bugzilla Bug #18380).
   This hack gives at least a nicer output (hdeller@redhat.com)
*/
static __inline__ unsigned int trimzero( int x )
{
	if (x<=0)
		return 0;
	return x;
}

/*
 * Process keyboard input during the main loop
 */
void do_key(char c)
{
	int numinput, i;
	char rcfile[MAXNAMELEN];
	FILE *fp;

	/*
	 * First the commands which don't require a terminal mode switch.
	 */
	if (c == 'q')
		end(0);
	else if (c == ' ')
		return;
	else if (c == 12) {
		clear_screen();
		return;
	}

	/*
	 * Switch the terminal to normal mode.  (Will the original
	 * attributes always be normal?  Does it matter?  I suppose the
	 * shell will be set up the way the user wants it.)
	 */
	if (!Batch) tcsetattr(0, TCSANOW, &Savetty);

	/*
	 * Handle the rest of the commands.
	 */
	switch (c) {
	case '?':
	case 'h':
		PUTP(cl); PUTP(ho); putchar('\n'); PUTP(mr);
		printf("kptop " KPTOP_VERS);
		PUTP(me); putchar('\n');
		fputs("\n\n", stdout);
		printf("%s\n\nPress any key to continue", HELP_SCREEN);
		if (!Batch) tcsetattr(0, TCSANOW, &Rawtty);
		(void) getchar();
		break;
	case 'a':
		Accumulate = !Accumulate;
		break;
	case 'b':
		SHOWMESSAGE(("Begin profiling"));
		kp_start();
		running = 1;
		break;
	case 'e':
		SHOWMESSAGE(("End profiling"));
		kp_stop();
		running = 0;
		break;
	case 'i':
		Idle = !Idle;
		break;
	case 'r':
		SHOWMESSAGE(("Reset profiling data"));
		kp_reset();
		if (running)
			kp_start();
		break;
	case 'p':
	{
		int newpid;

		PUTP(md);
		SHOWMESSAGE(("Pid to profile: "));
		newpid = getint();
		PUTP(top_clrtoeol);
		if (newpid < 0)
			SHOWMESSAGE(("Bad pid"));
		else {
			pid = newpid;
			SHOWMESSAGE(("Set pid to %d", pid));
			kp_reset();
			kp_set_pid((u_long)pid);
			if (running)
				kp_start();
		}
		PUTP(me);
		break;
	}
	case 'g':
	{
		char *filename;
		if (Accumulate == 0) {
			SHOWMESSAGE(("Cannot generate gmon.out unless accumulating"));
			break;
		}
		PUTP(md);
		SHOWMESSAGE(("Filename (gmon.out): "));
		filename = getstr();
/*		PUTP(me);*/
		SHOWMESSAGE(("name: %s\n", filename));
		kp_write_file(filename[0] ? filename : "gmon.out");
		if (running)
			kp_start();
		break;
	}
	case 'k':
	{
		int pid, signal;
		PUTP(md);
		SHOWMESSAGE(("PID to kill: "));
		pid = getint();
		if (pid == BAD_INPUT)
			break;
		PUTP(top_clrtoeol);
		SHOWMESSAGE(("Kill PID %d with signal [15]: ", pid));
		PUTP(me);
		signal = getsig();
		if (signal == -1)
			signal = SIGTERM;
		if (kill(pid, signal))
			SHOWMESSAGE(("\aKill of PID %d with %d failed: %s",
				     pid, signal, strerror(errno)));
	}
		break;
	case 'l':
		SHOWMESSAGE(("Display load average %s", !show_loadav ? "on" : "off"));
		if (show_loadav) {
			show_loadav = 0;
			header_lines--;
		} else {
			show_loadav = 1;
			header_lines++;
		}
		Numfields = make_header();
		break;
	case 'n':
	case '#':
		printf("Functions to display (0 for unlimited): ");
		numinput = getint();
		if (numinput != BAD_INPUT) {
			Display_funcs = numinput;
			window_size(0);
		}
		break;
	case 'N':
		SHOWMESSAGE(("Sort by name"));
		sort_type = S_NAME;
		reset_sort_options();
		register_sort_function(-1, (cmp_t)name_sort);
		break;
	case 'A':
		SHOWMESSAGE(("Sort by address"));
		sort_type = S_NONE;
		reset_sort_options();
		break;
	case 'C':
		SHOWMESSAGE(("Sort by count"));
		sort_type = S_COUNT;
		reset_sort_options();
		register_sort_function(-1, (cmp_t)count_sort);
		break;
	case 's':
	{
		double tmp;
		PUTP(md);
		SHOWMESSAGE(("Delay between updates: "));
		tmp = getfloat();
		if (!(tmp < 0))
			Sleeptime = tmp;
		PUTP(me);
	}
		break;
	case 'B':
	{
		int ret;

		kp_reset();
		if (mode == 0)
			ret = kp_set_mode(PROF_MODE_BACKTRACE);
		else if (got_mcount)
			ret = kp_set_mode(PROF_MODE_PC_SAMPLING |
					  PROF_MODE_CALL_GRAPH);
		else
			ret = kp_set_mode(PROF_MODE_PC_SAMPLING);
		if (ret)
			SHOWMESSAGE(("Couldn't change profiling mode"));
		else {
			mode = !mode;
			if (mode == 1)
				SHOWMESSAGE(("Now in backtrace mode"));
			else if (got_mcount)
				SHOWMESSAGE(("Now in annotated call graph mode"));
			else
				SHOWMESSAGE(("Now in PC sampling mode"));
		}
		if (running)
			kp_start();
		break;
	}
	case 'f':
	case 'F':
		change_fields();
		break;
	case 'o':
	case 'O':
		change_order();
		break;
	case 'W':
		if (getenv("HOME")) {
			strcpy(rcfile, getenv("HOME"));
			strcat(rcfile, "/");
			strcat(rcfile, RCFILE);
			fp = fopen(rcfile, "w");
			if (fp != NULL) {
				fprintf(fp, "%s\n", Fields);
				i = (int) Sleeptime;
				if (i < 2)
					i = 2;
				if (i > 9)
					i = 9;
				fprintf(fp, "%d", i);
				if (!show_loadav)
					fprintf(fp, "l");
				if (!Accumulate)
					fprintf(fp, "a");
				if (sort_type == S_NAME)
					fprintf(fp, "N");
				else if (sort_type == S_COUNT)
					fprintf(fp, "C");
				fprintf(fp, "\n");
				fclose(fp);
				SHOWMESSAGE(("Wrote configuration to %s", rcfile));
			} else {
				SHOWMESSAGE(("Couldn't open %s", rcfile));
			}
		} else {
			SHOWMESSAGE(("Couldn't get $HOME -- not saving"));
		}
		break;
	default:
		SHOWMESSAGE(("\aUnknown command `%c' -- hit `h' for help", c));
	}

	/*
	 * Return to raw mode.
	 */
	if (!Batch) tcsetattr(0, TCSANOW, &Rawtty);
	return;
}

prof_t **getproftable(prof_t **table, int *table_len)
{
	table = kp_get_prof(table, table_len, &tot_ticks);
	if (!Accumulate) {
		kp_reset();
		kp_start();
	}
	if (!Idle) {
		int i;
		/* remove the idle ticks */
		for (i = 0; i < *table_len; i++) {
			if (table[i]->name &&
			    strcmp(table[i]->name, "cpu_idle") == 0) {
				tot_ticks -= table[i]->count;
				table[i]->count = 0;
				break;
			}
		}
	}
	return table;
}


/* Code derived libproc's whattime.c: */

/* This is a trivial uptime program.  I hereby release this program
 * into the public domain.  I disclaim any responsibility for this
 * program --- use it at your own risk.  (as if there were any.. ;-)
 * -michaelkjohnson (johnsonm@sunsite.unc.edu)
 *
 * Modified by Larry Greenfield to give a more traditional output,
 * count users, etc.  (greenfie@gauss.rutgers.edu)
 *
 * Modified by mkj again to fix a few tiny buglies.
 *
 * Modified by J. Cowley to add printing the uptime message to a
 * string (for top) and to optimize file handling.  19 Mar 1993.
 *
 */

static char buf[128];
double av[3];

char *sprint_loadavg(void)
{
  int pos;
  struct tm *realtime;
  time_t realseconds;

  time(&realseconds);
  realtime = localtime(&realseconds);
  pos = sprintf(buf, " %2d:%02d%s  ",
		realtime->tm_hour%12 ? realtime->tm_hour%12 : 12,
		realtime->tm_min, realtime->tm_hour > 11 ? "pm" : "am");

  pos += sprintf(buf + pos, "Samples: %d, ", tot_ticks);

  if (pid)
	  pos += sprintf(buf + pos, "Pid: %d, ", pid);

  pos += sprintf(buf + pos, "Mode: %s, ", (mode ? "ct" : got_mcount ? "acg" : "pc"));

  loadavg(&av[0], &av[1], &av[2]);

  pos += sprintf(buf + pos, " load average: %.2f, %.2f, %.2f",
		 av[0], av[1], av[2]);

  return buf;
}
