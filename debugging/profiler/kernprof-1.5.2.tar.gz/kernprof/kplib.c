/*
 * kplib.c  Used by kptop to create a UI for the kernel profiler.
 *
 * Derived from GPLed sources for "kernprof", maintained at oss.sgi.com.
 */

/*
 *  kernprof.c - control kernel profiling
 *
 *  Copyright (C) 1999, 2000, 2001 SGI
 *
 *  Written by Dimitris Michailidis (dimitris@engr.sgi.com)
 *  Modifications by John Hawkes (hawkes@engr.sgi.com)
 *  Contributions from Niels Christiansen (nchr@us.ibm.com)
 *  Contributions from Ethan Solomita (ethan@cs.columbia.edu)
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define __SMP__
#define CONFIG_MCOUNT 1

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/gmon.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>
#include <sched.h>
#include <linux/kernprof.h>
#include <linux/threads.h>
#include <linux/module.h>
#include "kplib.h"

#define VERSION "1.4"

#define SLEEP_MSEC 200
#define DEFAULT_MAP "/usr/src/linux/System.map"
#define defaultGprofOutFile "gmon.out"

#define PTR_ALIGNED  __attribute__ ((aligned (__alignof__ (char *))))

/* This must match the kernel's definition. */
struct cg_arc_dest {
	kaddress_t address;
	int count;
	unsigned short link;
	unsigned short pad;
};

/*
 * Stores memory mapping of profiler buckets
 */
static prof_mem_map_t  memory_map;

/* These should match the kernel's definition. */
#define PROF_SET_ENABLE_MAP     _IOW(0xAF, 13, cpu_map_t)
#define PROF_GET_ENABLE_MAP     _IOR(0xAF, 14, cpu_map_t)
#define PROF_GET_MAPPING        _IOR(0xAF, 15, long)

static int proc_fds[NR_CPUS], out_fds[NR_CPUS];
static unsigned long sleep_msec = SLEEP_MSEC;  /* sleep interval */
static int ctl_fd = -1;
static FILE *kp_map = NULL;
static void (*kp_err)(int) = NULL;
static char *kp_prgname = NULL;

static void err_exit(const char *s) 
{
	kp_exit();
	perror(s);
	kp_err(1);
}

static void prof_ioctl(int request, unsigned long arg)
{
	if (ioctl(ctl_fd, request, arg))
		err_exit("/dev/profile: ioctl");
}

static int __inline__ get_prof_info(int entry)
{
	int val;
   
	prof_ioctl(entry, (unsigned long) &val);
	return val;
}

static cpu_map_t __inline__ get_prof_info_bitmap(int entry)
{
   cpu_map_t val;

   prof_ioctl(entry, (unsigned long) &val);
   return val;
}

/*
 * Read the contents of a file into a dynamically allocated buffer.
 * Also return the size of the buffer.
 */
static char *read_file(const char *name, size_t *lenp)
{
	char *buf;
	int fd;
	off_t end;
	size_t len;
   
	if ((fd = open(name, O_RDONLY)) < 0 || (end = lseek(fd, 0, SEEK_END)) < 0 ||
	    lseek(fd, 0, SEEK_SET) < 0)
		return NULL;

	len = (size_t) end;
	if ((buf = malloc(len)) == NULL)
		err_exit("malloc");

	if (read(fd, buf, len) != len)
	{
		fprintf(stderr, "Can't read %s\n", name);
		err_exit(name);
	}

	close(fd);
	if (lenp) *lenp = len;
	return buf;
}

/* Get a symbol's address from a file that obeys the format of /proc/ksyms */
static address_t get_symbol_address(FILE *fp, const char *name)
{
	char mapline[256], sym_name[256];
	kaddress_t addr;
   
	while (fgets(mapline, sizeof mapline, fp)) {
		if (sscanf(mapline, "%" SCANF_PREFIX "lx %s", &addr, sym_name) != 2) {
			fprintf(stderr,"%s: corrupt map file\n", kp_prgname);
			kp_err(1);
		}
		if (!strncmp(sym_name, name, strlen(name)))
			return (address_t) addr;
	}
	return 0;
}

static prof_t **gentable_pc(prof_t **table, int *entries, int *ticks)
{
	unsigned int step, index;
	ulong total_ticks = 0;
	address_t addr0 = 0;
	address_t addr, next_addr;        /* current and next symbol addresses */
	char name[256], next_name[256];   /* current and next symbol names */
	char mode[8], mapline[256];
	PC_sample_count_t *samples;
	static int tab_size = 1024;
	int count = 0;

	if (table) {
		prof_t **entry;
		
		for (entry = table; *entry; entry++)
			free(*entry);

		free(table);
	}
	table = malloc(tab_size * sizeof(*table));
	if (table == NULL) {
		*entries = 0;
		*ticks = 0;
		return NULL;
	}
	samples = (PC_sample_count_t *)read_file("/proc/profile/PC_samples", NULL);
	rewind(kp_map);
   
	step = get_prof_info(PROF_GET_PC_RES);

	index = 0;
	while (fgets(mapline, sizeof mapline, kp_map)) {
		unsigned int end_idx, tot_samples = 0;

		if (sscanf(mapline, "%lx %s %s", &next_addr, mode, next_name) != 3) {
			fprintf(stderr, "%s: corrupt map file\n", kp_prgname);
			kp_err(1);
		}

		if (addr0 == 0) {                               /* bootstrapping */
			if (strcmp(next_name, "_stext")) continue;
			addr0 = addr = next_addr;
			strcpy(name, next_name);
			continue;
		}

		end_idx = (next_addr - addr0) / step;
		while (index < end_idx) {
			tot_samples += samples[index++];
		}
		if (tot_samples > 0) {
			prof_t *entry;

			if ((entry = malloc(sizeof(prof_t))) == NULL)
				goto out;

			if (count + 1 == tab_size) {
				prof_t **newtable;
				
				newtable = realloc(table, tab_size * 2 * sizeof(*table));
				if (newtable == NULL) {
					free (entry);
					goto out;
				}
				table = newtable;
				tab_size *= 2;
			}
			entry->addr = addr;
			entry->count = tot_samples;
			strncpy(entry->name, name, sizeof(entry->name) - 1);
			entry->name[sizeof(entry->name)-1] = '\0';

			table[count++] = entry;
			total_ticks += tot_samples;
		}

		addr = next_addr;
		strcpy(name, next_name);
		if (*mode == '?' || !strcmp(name, "_etext")) /* only text is profiled */
			break;
	}
out:
	table[count] = NULL;
	*entries = count;
	*ticks = total_ticks;
	free(samples);
	return table;
}

#define SET_PROF_RATE(hdr) \
{ \
   int rate = get_prof_info(PROF_GET_SAMPLE_FREQ); \
   if (get_prof_info(PROF_GET_DOMAIN) == PROF_DOMAIN_TIME) { \
      *(int *) (hdr).prof_rate = rate; \
      strncpy((hdr).dimen, "seconds", sizeof (hdr).dimen); \
      (hdr).dimen_abbrev = 's'; \
   } else { \
      *(int *) (hdr).prof_rate = -rate; \
      snprintf((hdr).dimen, sizeof (hdr).dimen, "events (%#x)", get_prof_info(PROF_GET_PERFCTR_EVENT)); \
      (hdr).dimen_abbrev = 'e'; \
   } \
}

static void write_gprof_pc_hist(
	int fd,
	address_t lowpc,
	address_t highpc,
	PC_sample_count_t *buf,
	int hist_size,
	int start_index)
{
	u_char tag = GMON_TAG_TIME_HIST;
	struct gmon_hist_hdr thdr PTR_ALIGNED;
	char *cbuf;
	size_t len;
	int end = start_index + hist_size;
	int need_free = 0;
   
	if (buf == NULL) {
		buf = (PC_sample_count_t *) read_file("/proc/profile/PC_samples", &len);
		need_free = 1;
	}
	cbuf = (char *)buf;
   
	/* gprof history buckets are of type HISTCOUNTER so we may need to convert
	 * our samples
	 */
	if (sizeof(HISTCOUNTER) < sizeof(PC_sample_count_t)) {
		HISTCOUNTER *b;
		PC_sample_count_t *p;
		int i;

		b = (HISTCOUNTER *) p = buf;
		for (i = start_index; i < end; ++i)
			b[i] = p[i];
	}
   
	{
		struct iovec iov[3] = {
			{ &tag, sizeof(tag) },
			{ &thdr, sizeof(struct gmon_hist_hdr) },
			{ cbuf + start_index * sizeof(HISTCOUNTER), hist_size * sizeof(HISTCOUNTER) }
		};
		kaddress_t val;
		
		val = (kaddress_t)lowpc;
		memcpy(thdr.low_pc, &val, sizeof(val));
		val = (kaddress_t)highpc;
		memcpy(thdr.high_pc, &val, sizeof(val));
		*(int *) thdr.hist_size = hist_size;
		SET_PROF_RATE(thdr);
      
		writev(fd, iov, 3);
	}
	if (need_free)
		free(buf);
}

/* round x up to a multiple of n.  n must be a power of 2 */
static inline size_t roundup(size_t x, int n)
{
	return (x + n - 1) & ~(n - 1);
}

#define NARCS_PER_WRITEV 32

static void write_gprof_call_graph(
	int fd,
	address_t lowpc,
	address_t highpc,
	unsigned short *froms,
	int from_len,
	struct cg_arc_dest *tos)
{
	u_char tag = GMON_TAG_CG_ARC;
	struct gmon_cg_arc_record raw_arc[NARCS_PER_WRITEV] PTR_ALIGNED;
	int from_index, nfilled, step;
	int need_free = 0;
	unsigned short *fromc;
	struct cg_arc_dest *toc;
	struct iovec iov[2 * NARCS_PER_WRITEV];
	char *buf = NULL;
	char *b;
	char *p;
	int cpu;
	int to_index;
	int next_index;
	int i;
	int curix;
	address_t frompc;
	long total_count = 0L;
	long cg_input = 0L;
	long cg_merged = 0L;
	long cg_base = 0L;
	long cg_records = 0L;
	long lost_ones = 0L;
   
	for (nfilled = 0; nfilled < NARCS_PER_WRITEV; ++nfilled) {
		iov[2 * nfilled].iov_base = &tag;
		iov[2 * nfilled].iov_len = sizeof tag;
		iov[2 * nfilled + 1].iov_base = &raw_arc[nfilled];
		iov[2 * nfilled + 1].iov_len = sizeof(struct gmon_cg_arc_record);
	}
   
	nfilled = 0;
	step = get_prof_info(PROF_GET_PC_RES);
	if (froms)
		goto done_merge;
	
	need_free = 1;
	buf = read_file("/proc/profile/call_graph", NULL);
	if (buf == NULL)
		return;		/* PC sampling mode without call graph? */
	froms = (unsigned short *) buf;
	from_len = (highpc - lowpc) / step;
	p = buf + memory_map.cg_to_offset;
	tos = (struct cg_arc_dest *)p;

	b = buf;
	curix = tos[0].count + 1;
	
	for (cpu = 0; cpu < memory_map.nr_cpus; cpu++)
	{
		b = buf + memory_map.cg_from_size * cpu;
		fromc = (unsigned short *)b;
		p = buf + memory_map.cg_to_offset + memory_map.cg_to_size * cpu;
		toc = (struct cg_arc_dest *)p;
		for (from_index = 0; from_index < from_len; ++from_index)
		{
			frompc = lowpc + from_index * step;
			for (to_index = fromc[from_index]; to_index != 0; to_index = toc[to_index].link)
			{
				cg_input++;
				if (!cpu)
				{
					cg_base++;
					continue;
				}
				for (i = froms[from_index]; i != 0; i = tos[i].link)
				{
					if (tos[i].address == toc[to_index].address)
					{
						cg_merged++;
						tos[i].count += toc[to_index].count;
						break;
					}
				}
				if (i == 0)
				{
					if (curix >= CG_MAX_ARCS)
						lost_ones++;
					else
					{
						tos[curix].link = froms[from_index];
						tos[curix].address = toc[to_index].address;
						tos[curix].count = toc[to_index].count;
						froms[from_index] = curix++;
					}
				}
			}
		}
	}
done_merge:
	
	for (from_index = 0; from_index < from_len; ++from_index)
	{
		frompc = lowpc + from_index * step;
		
		for (to_index = froms[from_index]; to_index != 0;
		     to_index = tos[to_index].link)
		{
			kaddress_t val;
			
			val = (kaddress_t)frompc;
			memcpy(raw_arc[nfilled].from_pc, &val, sizeof(val));
			val = (kaddress_t)tos[to_index].address;
			memcpy(raw_arc[nfilled].self_pc, &val, sizeof(val));
			*(int *) raw_arc[nfilled].count = tos[to_index].count;
			total_count += tos[to_index].count;
			cg_records++;
			if (++nfilled == NARCS_PER_WRITEV)
			{
				writev (fd, iov, 2 * NARCS_PER_WRITEV);
				nfilled = 0;
			}
		}
	}
   
	if (nfilled > 0)
		writev(fd, iov, 2 * nfilled);
	if (need_free)
		free(buf);
}

/* write gmon.out header */
static void write_gprof_hdr(int fd)
{
	struct gmon_hdr ghdr PTR_ALIGNED;

	memset(&ghdr, 0, sizeof ghdr);
	memcpy(&ghdr.cookie[0], GMON_MAGIC, sizeof(ghdr.cookie));
	*(int *) ghdr.version = GMON_VERSION;
	write(fd, &ghdr, sizeof ghdr);
}

/* generate a call graph data file for gprof */
static void output_cg_profile(const char *outFile)
{
	int fd;
	unsigned int step;
	address_t lowpc, highpc;
   
	step = get_prof_info(PROF_GET_PC_RES);
	lowpc = memory_map.kernel_start;
	highpc = memory_map.kernel_end;

	if ((fd = creat(outFile ? outFile : defaultGprofOutFile, 0666)) == 0)
		err_exit(outFile);
	write_gprof_hdr(fd);
	write_gprof_pc_hist(fd, lowpc, highpc, NULL, memory_map.kernel_buckets, 0);
	write_gprof_call_graph(fd, lowpc, highpc, NULL, 0, NULL);
	close(fd);
}

static void write_gprof_call_stack_sampling_header(int fd)
{
	u_char tag = GMON_TAG_CALL_STACK_SAMPLING_HDR;
	struct gmon_call_stack_sampling_hdr_record hdr PTR_ALIGNED;
	struct iovec iov[2] = {
		{ &tag, sizeof tag },
		{ &hdr, sizeof hdr }
	};

	SET_PROF_RATE(hdr);
	writev (fd, iov, 2);
}

/*
 * When writing call traces we compress the output file by agreggating
 * all the module and user samples.  This is easy to do because all these
 * traces have a single entry that is either UNKNOWN_KERNEL or USER.  The two
 * variables below are initialized to the addresses of these two symbols.
 */

static void convert_to_gprof_format(int in, int out)
{
	address_t lowpc, highpc;
	int i, res, next_to, high_to, step, idx, max_idx;
	address_t upcs[PROF_BACKTRACE_MAX_LEN];
	kaddress_t len, count, kpcs[PROF_BACKTRACE_MAX_LEN];
	size_t l;
	FILE *map;
	PC_sample_count_t *pcs;
	unsigned short *froms;
	struct cg_arc_dest *tos;

	if ((map = fopen("/proc/ksyms", "r")) == NULL)
		err_exit("/proc/ksyms");
	if ((lowpc = get_symbol_address(map, "_stext")) == 0) {
		fprintf(stderr, "%s: can't find \"_stext\" in /proc/ksyms\n", kp_prgname);
		kp_err(1);
	}
	if ((highpc = get_symbol_address(map, "_etext")) == 0) {
		fprintf(stderr, "%s: can't find \"_etext\" in /proc/ksyms\n", kp_prgname);
		kp_err(1);
	}
	fclose(map);

	step = get_prof_info(PROF_GET_PC_RES);
	max_idx = (highpc - lowpc) / step;
	pcs = malloc(max_idx * sizeof(*pcs));
	froms = malloc(max_idx * sizeof(*froms));
	tos = malloc(64 * 1024);

	if (pcs == NULL || froms == NULL || tos == NULL)
		err_exit("malloc");
   
	next_to = 1;
	high_to = (64*1024) / sizeof(*tos);

	write_gprof_hdr(out);

	while ((res = read(in, &len, sizeof len)) == sizeof len) {
		/* "len" holds the count in the upper half, len in the lower */
		count = len >> ((sizeof len) * 4);
		if (count == 0)
			count = 1;		/* backwards compat -- "0" means 1 */
		len &= (1LL << ((sizeof len) * 4)) - 1;
      
		if (len > PROF_BACKTRACE_MAX_LEN) {
			fprintf(stderr,
				"from: trace entry too long, suspect data corruption\n");
			kp_err(1);
		}

		l = (size_t) len * sizeof(kaddress_t);

		/*
		 * If kernel- and user-space addresses are the same we read straight into
		 * upcs, otherwise we read the kernel addresses into a temporary buffer
		 * and convert them later into addresses user applications can handle.
		 */
		res = read(in, sizeof(address_t) == sizeof(kaddress_t)
			   ? (char *)&upcs : (char *)&kpcs, l);

		if (res != l) {
			if (res != 0) break;
			fprintf(stderr, "from: premature end-of-file\n");
			kp_err(1);
		}

		if (sizeof(address_t) != sizeof(kaddress_t)) {
			for (i = 0; i < (int) len; i++)
				upcs[i] = kpcs[i];
		}

		if (upcs[0] < lowpc || upcs[0] >= highpc)
			err_exit("bad pc");
		idx = (upcs[0] - lowpc) / step;
		pcs[idx] += count;
		if (pcs[idx] < count)
			fprintf(stderr, "from: pc 0x%x count wrapped", upcs[0]);

		for (i = 1; i < (int) len; i++) {
			int to_idx;
	 
			if (upcs[i] < lowpc || upcs[i] >= highpc)
				err_exit("bad pc");

			if (next_to == high_to) {
				high_to *= 2;
				tos = realloc(tos, high_to * sizeof(*tos));
			}
	 
			idx = (upcs[i] - lowpc) / step;
			to_idx = froms[idx];
			while (to_idx && tos[to_idx].address != upcs[i-1])
				to_idx = tos[to_idx].link;
			if (to_idx)
				tos[to_idx].count += count;
			else {
				to_idx = next_to++;
				tos[to_idx].link = froms[idx];
				tos[to_idx].address = upcs[i-1];
				tos[to_idx].count = count;
				froms[idx] = to_idx;
			}
		}
	}
	if (res < 0)
		err_exit("convert_to_gprof_format");
	else if (res != 0) {
		fprintf(stderr, "from: unexpected read size\n");
		kp_err(1);
	}

	write_gprof_pc_hist(out, lowpc, highpc, pcs, memory_map.kernel_buckets, 0);
	write_gprof_call_graph(out, lowpc, highpc, froms, max_idx, tos);
	free(tos);
	free(froms);
	free(pcs);
}

static void bt_pull_data()
{
	int n = 0, i;
	char s[256];
	struct sched_param sched_prio;
	cpu_map_t map = get_prof_info_bitmap(PROF_GET_ENABLE_MAP);
	kaddress_t buf[PROF_BACKTRACE_BUFSIZE - 1];
	ssize_t len;
   
	/* We become low priority RT so we can copy the buffers quickly */
	sched_getparam(0, &sched_prio);
	sched_prio.sched_priority = 1;
	sched_setscheduler(0, SCHED_FIFO, &sched_prio);
   
	for (i = 0; i < NR_CPUS; ++i) {
		if (proc_fds[i] == -1 || (map & (((cpu_map_t)1) << i)) == 0)
			continue;

		if (out_fds[i] == -1) {
			sprintf(s, "call_trace.%d", i);
			out_fds[i] = open(s, O_RDWR|O_CREAT|O_TRUNC, 0666);
		}
		if (out_fds[i] == -1)
			err_exit(s);
		
		if ((len = read(proc_fds[i], buf, sizeof buf)) > 0)
			if (write(out_fds[i], buf, len) != len)
				err_exit("error writing call backtraces\n");
	}

	/* Go back to normal priority */
	sched_prio.sched_priority = 0;
	sched_setscheduler(0, SCHED_OTHER, &sched_prio);
}

void output_bt_profile(char *outFile)
{
	int i;

	if (!outFile)
		outFile = defaultGprofOutFile;
	for (i = 0; i < NR_CPUS; ++i) {
		char s[256];
		int to;
		
		if (out_fds[i] == -1)
			continue;
		
		sprintf(s, "%s.cpu%d", outFile, i);
		if ((to = creat(s, 0666)) == -1)
			continue;

		lseek(out_fds[i], 0, SEEK_SET);
		convert_to_gprof_format(out_fds[i], to);
		lseek(out_fds[i], 0, SEEK_END);
		close(to);
	}
}	

int
kp_init(char *mapfile, void (*errfunc)(int), char *progname)
{
	int i;
	char s[20];
	
	if ((ctl_fd = open("/dev/profile", O_RDONLY)) == -1)
		return -1;
	if ((kp_map = fopen(mapfile ? mapfile : DEFAULT_MAP, "r")) == NULL) {
		close(ctl_fd);
		return -1;
	}
	for (i = 0; i < NR_CPUS; ++i) {
		sprintf(s, "/dev/profile%d", i);
		proc_fds[i] = open(s, O_RDONLY);
		out_fds[i] = -1;
	}
	kp_err = errfunc;
	kp_prgname = progname;
	return 0;
}

void
kp_exit(void)
{
	int i;
	char s[20];

	if (ctl_fd == -1)
		return;
	
	kp_reset();
	
	for (i = 0; i < NR_CPUS; ++i) {
		sprintf(s, "call_trace.%d", i);
		unlink(s);
	}
}

void
kp_stop(void)
{
	prof_ioctl(PROF_STOP, 0);
	prof_ioctl(PROF_GET_MAPPING, (unsigned long) &memory_map);
}

void
kp_reset(void)
{
	int i;
	char s[20];

	for (i = 0; i < NR_CPUS; ++i) {
		if (out_fds[i] != -1) {
			close(out_fds[i]);
			out_fds[i] = -1;
		}
	}
	prof_ioctl(PROF_RESET, 0);
	prof_ioctl(PROF_GET_MAPPING, (unsigned long) &memory_map);
}

void
kp_set_sleep(u_int sleep) 
{
	sleep_msec = sleep;
}

/*
 * User can specify the lower 20 bits that will be loaded into PerfEvtSel0.
 * IA32 specific.
 */

int
kp_set_event(u_int event)
{
	if (event > 0xFFFFF)
		return -1;

	if (event < 0x100)
		event |= 0x30000;
	return ioctl(ctl_fd, PROF_SET_PERFCTR_EVENT, (unsigned long) event);
}

int
kp_set_pid(u_long pid)
{
	return ioctl(ctl_fd, PROF_SET_PID, pid);
}

int
kp_set_mode(u_int mode)
{
	if (mode != PROF_MODE_PC_SAMPLING &&
	    mode != (PROF_MODE_PC_SAMPLING | PROF_MODE_CALL_GRAPH) &&
	    mode != PROF_MODE_BACKTRACE &&
	    mode != PROF_MODE_CALL_GRAPH &&
	    mode != PROF_MODE_CALL_COUNT &&
	    mode != PROF_MODE_SCHEDULER_CALL_GRAPH)
		return -1;
	
	return ioctl(ctl_fd, PROF_SET_MODE, mode);
}

int
kp_set_domain(u_int domain)
{
	if (domain != PROF_DOMAIN_TIME &&
	    domain != PROF_DOMAIN_PERFCTR)
		return -1;

	return ioctl(ctl_fd, PROF_SET_DOMAIN, domain);
}

int
kp_set_freq(u_int freq)
{
	return ioctl(ctl_fd, PROF_SET_SAMPLE_FREQ, freq);
}

void
kp_set_cpu_map(cpu_map_t cpu_map)
{
	prof_ioctl(PROF_SET_ENABLE_MAP, (u_long)&cpu_map);
}

void
kp_get_cpu_map(cpu_map_t *cpu_map)
{
	prof_ioctl(PROF_GET_ENABLE_MAP, (u_long)cpu_map);
}

void
kp_start(void)
{
	prof_ioctl(PROF_START, 0);
}

prof_t **
kp_get_prof(prof_t **table, int *entries, int *ticks)
{
	if (get_prof_info(PROF_GET_MODE) == PROF_MODE_BACKTRACE)
		bt_pull_data();
	
	prof_ioctl(PROF_GET_MAPPING, (unsigned long) &memory_map);
	return gentable_pc(table, entries, ticks);
}

void
kp_write_file(char *filename)
{
	prof_ioctl(PROF_GET_MAPPING, (unsigned long) &memory_map);
	prof_ioctl(PROF_STOP, 0); /* to avoid any races and freeze the data */
	if (get_prof_info(PROF_GET_MODE) == PROF_MODE_BACKTRACE) {
		bt_pull_data();
		output_bt_profile(filename);
	} else
		output_cg_profile(filename);
}
